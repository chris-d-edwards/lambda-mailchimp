var Mailchimp = require('mailchimp-api-v3') ; 
var mailchimp = new Mailchimp('your-mailchimp-api-key'); 

exports.handler = (event, context, callback) => {
    
    callback(null, {
        statusCode: '200',
        body: JSON.stringify(event),
        headers: {
            'Content-Type': 'application/json',
        },    
};
